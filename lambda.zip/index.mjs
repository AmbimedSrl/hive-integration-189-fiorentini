#!/usr/bin/env node
/**
 * AWS Lambda (Node.js 22.x, ES-modules) that:
 *   1. Generates an IAM auth token through an RDS Proxy using @aws-sdk/rds-signer
 *   2. Executes the SQL contained in ../../query.sql against a MySQL/MariaDB database
 *   3. Sends the resulting rows as JSON via HTTP POST to the endpoint defined in `API_ENDPOINT`
 *
 * Environment variables expected by the function:
 *   DB_HOST        – RDS Proxy endpoint (hostname only)
 *   DB_PORT        – TCP port, default `3306`
 *   DB_NAME        – Database name
 *   DB_USER        – Database user mapped to IAM role
 *   API_ENDPOINT   – HTTPS URL that will receive the results
 *   COMPANY_ID     – Value injected into the `@company_id` SQL variable inside query.sql
 *   AWS_REGION     – Provided automatically by Lambda, required by the signer
 *
 * Type annotations are provided via JSDoc so they work in plain JavaScript too.
 */

import { Signer } from "@aws-sdk/rds-signer";
import { fromNodeProviderChain } from "@aws-sdk/credential-providers";
import mysql from "mysql2/promise";
import fs from "node:fs/promises";

// ────────────────────────────────────────────────────────────────────────────────
// Read the SQL file once at cold-start and keep it cached.
// Using URL keeps it working when the file is bundled.
/** @type {Promise<string>} */
const rawQueryPromise = fs.readFile(
  new URL("./query.sql", import.meta.url),
  "utf8"
);

/**
 * Build an auth token for RDS IAM authentication.
 *
 * @param {object} opts
 * @param {string} opts.host     – RDS Proxy host
 * @param {number} opts.port     – RDS Proxy port
 * @param {string} opts.username – Database user
 * @param {string} opts.region   – AWS region
 * @returns {Promise<string>}    – Signed auth token (use as the password)
 */
async function getAuthToken({ host, port, username, region }) {
  const credentials = await fromNodeProviderChain()();
  const signer = new Signer({
    hostname: host,
    port,
    username,
    region,
    credentials,
  });
  return signer.getAuthToken();
}

/**
 * @typedef {import("mysql2/promise").RowDataPacket} RowDataPacket
 * @typedef {import("mysql2/promise").OkPacket}    OkPacket
 * @typedef {import("mysql2/promise").ResultSetHeader} ResultSetHeader
 *
 * @typedef {Record<string, unknown>} QueryRow – Shape of a single row returned by the query.
 */

/**
 * The Lambda entry point.
 *
 * @type {import("aws-lambda").Handler}
 */
export const handler = async (_event, _context) => {
  // Grab and validate env vars early – it helps with debugging.
  const {
    DB_HOST,
    DB_PORT = "3306",
    DB_NAME,
    DB_USER,
    API_ENDPOINT,
    COMPANY_ID,
    AWS_REGION,
  } = process.env;

  if (!DB_HOST || !DB_NAME || !DB_USER || !API_ENDPOINT || !COMPANY_ID) {
    throw new Error("Missing required environment variables.");
  }

  // Build the IAM auth token.
  const password = await getAuthToken({
    host: DB_HOST,
    port: Number(DB_PORT),
    username: DB_USER,
    region: AWS_REGION ?? process.env.AWS_REGION ?? "eu-west-1",
  });

  // Fetch and tailor the SQL string.
  const rawQuery = await rawQueryPromise;
  const sql = rawQuery.replace(/SET\s+@company_id\s*=\s*[^;]+;/i, `SET @company_id = ${Number(COMPANY_ID)};`);

  /** @type {mysql.Connection} */
  let connection;
  try {
    // Establish the connection using the token as the password.
    connection = await mysql.createConnection({
      host: DB_HOST,
      port: Number(DB_PORT),
      user: DB_USER,
      password,
      database: DB_NAME,
      ssl: {
        // Amazon Root CA trust – the MySQL client will fill in defaults when set to "Amazon RDS".
        rejectUnauthorized: true,
      },
    });

    // Run the multi-statement script (setting variable + select).
    /** @type {[QueryRow[], RowDataPacket[] | OkPacket | ResultSetHeader]} */
    const [rows] = await connection.query(sql);

    // Send the results to the external endpoint.
    const response = await fetch(API_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(rows),
    });

    return {
      statusCode: response.status,
      body: await response.text(),
    };
  } finally {
    if (connection) await connection.end();
  }
}; 